"""Initialization"""

from mplwidget.mplwidget import MplWidget
