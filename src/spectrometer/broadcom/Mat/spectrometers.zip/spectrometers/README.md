# spectrometers
A package to control various spectrometers
