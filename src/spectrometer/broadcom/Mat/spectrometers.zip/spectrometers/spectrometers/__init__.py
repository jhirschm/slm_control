"""Initialization"""

from spectrometers.devices.base import Spectrometer
from spectrometers.spectrum import *
from spectrometers.device import *
from spectrometers.gui import run
